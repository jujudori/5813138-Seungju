public class MyInfoApp {

	public static void main(String[] args) {
		System.out.println("황보승주");
		System.out.println("22살");
		System.out.println("department of computer engineering");

	}

}
